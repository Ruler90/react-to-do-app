chrome.browserAction.onClicked.addListener(function (tab) {
	chrome.tabs.create({'url': "to-do-app.html"})
});